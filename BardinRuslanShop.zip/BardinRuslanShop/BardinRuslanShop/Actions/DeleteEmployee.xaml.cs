﻿using BardinRuslanShop.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BardinRuslanShop.Windows
{
    /// <summary>
    /// Логика взаимодействия для DeleteEmployee.xaml
    /// </summary>
    public partial class DeleteEmployee : Window
    {
        Model.Computerny_magazinEntities computerny_MagazinEntities = new Model.Computerny_magazinEntities();
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgInfo.ItemsSource = computerny_MagazinEntities.Employee.ToList();
        }

        public DeleteEmployee()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id = 0;
            if (dgInfo.SelectedItem == null) { MessageBox.Show("Запись не была выбрана"); return; }
            try
            {
                id = computerny_MagazinEntities.Employee.ToList()[dgInfo.SelectedIndex].EmployeeID;

            }
            catch (System.ArgumentOutOfRangeException)
            {
                MessageBox.Show("Запись не была выбрана"); return;
            }
            Model.Employee employeeDel = computerny_MagazinEntities.Employee.Find(id);
            computerny_MagazinEntities.Employee.Remove(employeeDel);
            computerny_MagazinEntities.SaveChanges();
            MessageBox.Show("Удален");
            dgInfo.ItemsSource = computerny_MagazinEntities.Employee.ToList();
        }
    }
}
