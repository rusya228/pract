﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BardinRuslanShop.Windows
{
    /// <summary>
    /// Логика взаимодействия для EditEmployee.xaml
    /// </summary>
    public partial class EditEmployee : Window
    {
        Model.Computerny_magazinEntities computerny_MagazinEntities = new Model.Computerny_magazinEntities();
        public EditEmployee()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgInfo.ItemsSource = computerny_MagazinEntities.Employee.ToList();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (tbLogin.Text == "" || tbPassword.Text == "" || tbName.Text == "" || tbPatronymic.Text == "" || tbRole.Text == "" || tbSecondName.Text == "") { MessageBox.Show("Есть пустые поля"); return; }
            int id = 0;
            if (dgInfo.SelectedItem == null) { MessageBox.Show("Запись не была выбрана"); return; }
            try
            {
                id = computerny_MagazinEntities.Employee.ToList()[dgInfo.SelectedIndex].EmployeeID;

            }
            catch (System.ArgumentOutOfRangeException)
            {
                MessageBox.Show("Запись не была выбрана"); return;
            }
            Model.Employee employeeDel = computerny_MagazinEntities.Employee.Find(id);
            computerny_MagazinEntities.Employee.Remove(employeeDel);
            computerny_MagazinEntities.SaveChanges();
            Model.Employee employee = new Model.Employee();
            employee.EmployeeID = id;
            employee.Name = tbName.Text;
            employee.Patronymic = tbPatronymic.Text;
            employee.Password = tbPassword.Text;
            try
            {
                employee.RoleID = Convert.ToInt32(tbRole.Text);
            }
            catch
            {
                MessageBox.Show("Неверный формат входных данных");
                return;
            }
            employee.SecondName = tbSecondName.Text;
            employee.Login = tbLogin.Text;
            computerny_MagazinEntities.Employee.Add(employee);
            computerny_MagazinEntities.SaveChanges();
            MessageBox.Show("Изменен");
            dgInfo.ItemsSource = computerny_MagazinEntities.Employee.ToList();
        }
    }
}
